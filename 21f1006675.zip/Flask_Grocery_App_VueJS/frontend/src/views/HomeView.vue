<script setup>
// import TheWelcome from '../components/TheWelcome.vue'
import NavBar from "../components/NavBar.vue";
import ProductCard from "../components/ProductCard.vue";
</script>

<template>
  <!-- NAVBAR -->
  <main>
    <NavBar />
    <!-- PRODUCT CARD-->
    <ProductCard />
  </main>
  <!-- <h1>Home View Works</h1> -->
</template>

